﻿namespace WebApiP41.Models;

public class Message
{
    public int Id { get; set; }
    public string FromAddress { get; set; } = string.Empty;
    public string Text { get; set; } = string.Empty;
    public DateTime DateTime { get; set; }
}
